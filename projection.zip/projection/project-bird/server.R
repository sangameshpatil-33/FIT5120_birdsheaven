#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(ggplot2)
library(dplyr) 
library(tidyverse)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
    data1 <- read.csv('https://birdheaven.s3.ap-southeast-2.amazonaws.com/brown_headed_yearly.csv', header=T, sep=",") 
    data2 <- read.csv('https://birdheaven.s3.ap-southeast-2.amazonaws.com/new_holland_yearly.csv', header=T, sep=",") 
    data3 <- read.csv('https://birdheaven.s3.ap-southeast-2.amazonaws.com/white_napped_yearly.csv', header=T, sep=",") 
    
    
    
    output$line <- renderPlotly({
        if (input$specie == 'BrownHeaded'){
            
            model <- lm(Surveys~Year, data = (data1 %>% filter(Year > 2015)))
            pred_val <- predict(model, newdata = data.frame(Year = 2023))
            
            data1 <- data1 %>% add_row(Year = 2023, Surveys = pred_val)
            ggplot(data1 %>% filter(Year <= as.numeric(input$bins)), aes(Year, Surveys)) + geom_line()
            
        } else if (input$specie == 'New Holland'){
            
            model <- lm(Surveys~Year, data = (data2 %>% filter(Year > 2015)))
            pred_val <- predict(model, newdata = data.frame(Year = 2023))
            
            data2 <- data2 %>% add_row(Year = 2023, Surveys = pred_val)
            ggplot(data2 %>% filter(Year <= as.numeric(input$bins)), aes(Year, Surveys)) + geom_line()
            
        } else if (input$specie == 'White-napped'){
            
            model <- lm(Surveys~Year, data = (data3 %>% filter(Year > 2015)))
            pred_val <- predict(model, newdata = data.frame(Year = 2023))
            
            data3 <- data3 %>% add_row(Year = 2023, Surveys = pred_val)
            ggplot(data3 %>% filter(Year <= as.numeric(input$bins)), aes(Year, Surveys)) + geom_line(aes())
        }
        
        
    })
})
